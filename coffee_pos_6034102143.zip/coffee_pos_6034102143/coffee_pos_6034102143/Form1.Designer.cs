﻿namespace coffee_pos_6034102143
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.columnHeader1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.columnHeader2 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.About = new System.Windows.Forms.TabPage();
            this.linkLabel3 = new System.Windows.Forms.LinkLabel();
            this.linkLabel2 = new System.Windows.Forms.LinkLabel();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.Payment = new System.Windows.Forms.TabPage();
            this.label7 = new System.Windows.Forms.Label();
            this.show_bill = new System.Windows.Forms.Label();
            this.Home = new System.Windows.Forms.TabPage();
            this.nestca_tea_2 = new System.Windows.Forms.Button();
            this.Nescafe3 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.lemon_tea2 = new System.Windows.Forms.Button();
            this.milk_tea_frappe = new System.Windows.Forms.Button();
            this.Milk_frappe = new System.Windows.Forms.Button();
            this.CoCoa_frappe = new System.Windows.Forms.Button();
            this.Thai_Tea_frappe = new System.Windows.Forms.Button();
            this.GreenIce_frappe = new System.Windows.Forms.Button();
            this.Cappuccino_frappe = new System.Windows.Forms.Button();
            this.Mocha_frappe = new System.Windows.Forms.Button();
            this.Latte_frappe = new System.Windows.Forms.Button();
            this.Esspresso_frappe = new System.Windows.Forms.Button();
            this.honey_lime_soda = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.ls = new System.Windows.Forms.Button();
            this.nestca_tea = new System.Windows.Forms.Button();
            this.Nescafe2 = new System.Windows.Forms.Button();
            this.Milk2 = new System.Windows.Forms.Button();
            this.lemon_tea = new System.Windows.Forms.Button();
            this.milk_tea_ice = new System.Windows.Forms.Button();
            this.Milk_ice = new System.Windows.Forms.Button();
            this.CoCoa_ice = new System.Windows.Forms.Button();
            this.Thai_Tea_ice = new System.Windows.Forms.Button();
            this.GreenIce_ice = new System.Windows.Forms.Button();
            this.Cappuccino_ice = new System.Windows.Forms.Button();
            this.Mocha_ice = new System.Windows.Forms.Button();
            this.Latte_ice = new System.Windows.Forms.Button();
            this.Americano_ice = new System.Windows.Forms.Button();
            this.Esspresso_ice = new System.Windows.Forms.Button();
            this.nescafe1 = new System.Windows.Forms.Button();
            this.milo1 = new System.Windows.Forms.Button();
            this.Milk_hot = new System.Windows.Forms.Button();
            this.CoCoa_hot = new System.Windows.Forms.Button();
            this.Thai_Tea_hot = new System.Windows.Forms.Button();
            this.GreenIce_hot = new System.Windows.Forms.Button();
            this.Cappuccino_hot = new System.Windows.Forms.Button();
            this.Mocha_hot = new System.Windows.Forms.Button();
            this.Latte_hot = new System.Windows.Forms.Button();
            this.Americano_hot = new System.Windows.Forms.Button();
            this.Esspresso_hot = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.ok_pay = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.label4 = new System.Windows.Forms.Label();
            this.p_txt = new System.Windows.Forms.Label();
            this.clear = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.receive_money = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.Give_the_change = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.About.SuspendLayout();
            this.Payment.SuspendLayout();
            this.Home.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Mistral", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(17, 19);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(241, 57);
            this.label1.TabIndex = 0;
            this.label1.Text = "TonTan Coffee";
            // 
            // listView1
            // 
            this.listView1.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.columnHeader1,
            this.columnHeader2});
            this.listView1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.listView1.Location = new System.Drawing.Point(862, 113);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(381, 314);
            this.listView1.TabIndex = 2;
            this.listView1.UseCompatibleStateImageBehavior = false;
            this.listView1.View = System.Windows.Forms.View.Details;
            // 
            // columnHeader1
            // 
            this.columnHeader1.Text = "Product";
            this.columnHeader1.Width = 193;
            // 
            // columnHeader2
            // 
            this.columnHeader2.Text = "Price";
            // 
            // About
            // 
            this.About.Controls.Add(this.linkLabel3);
            this.About.Controls.Add(this.linkLabel2);
            this.About.Controls.Add(this.linkLabel1);
            this.About.Controls.Add(this.label5);
            this.About.Location = new System.Drawing.Point(4, 22);
            this.About.Name = "About";
            this.About.Padding = new System.Windows.Forms.Padding(3);
            this.About.Size = new System.Drawing.Size(821, 486);
            this.About.TabIndex = 2;
            this.About.Text = "About";
            this.About.UseVisualStyleBackColor = true;
            // 
            // linkLabel3
            // 
            this.linkLabel3.AutoSize = true;
            this.linkLabel3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.linkLabel3.Location = new System.Drawing.Point(145, 119);
            this.linkLabel3.Name = "linkLabel3";
            this.linkLabel3.Size = new System.Drawing.Size(337, 24);
            this.linkLabel3.TabIndex = 3;
            this.linkLabel3.TabStop = true;
            this.linkLabel3.Text = "https://github.com/PyThaiNLP/pythainlp";
            this.linkLabel3.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel3_LinkClicked);
            // 
            // linkLabel2
            // 
            this.linkLabel2.AutoSize = true;
            this.linkLabel2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.linkLabel2.Location = new System.Drawing.Point(145, 90);
            this.linkLabel2.Name = "linkLabel2";
            this.linkLabel2.Size = new System.Drawing.Size(316, 24);
            this.linkLabel2.TabIndex = 2;
            this.linkLabel2.TabStop = true;
            this.linkLabel2.Text = "https://github.com/wannaphongcom/";
            this.linkLabel2.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel2_LinkClicked);
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.linkLabel1.Location = new System.Drawing.Point(230, 66);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(419, 24);
            this.linkLabel1.TabIndex = 1;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "https://github.com/wannaphongcom/Coffee_POS";
            this.linkLabel1.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.linkLabel1_LinkClicked);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label5.Location = new System.Drawing.Point(24, 17);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(394, 225);
            this.label5.TabIndex = 0;
            this.label5.Text = "Author : Wannaphong Phatthiyaphaibun\r\nCIS @ NKC KKU\r\nCoffee POS GitHub : \r\nMy Git" +
    "Hub : \r\nMy Work :\r\n\r\nCoffee POS  using Apache License 2.0\r\n\r\nE-mail : wannaphong" +
    "@kkumail.com";
            // 
            // Payment
            // 
            this.Payment.Controls.Add(this.label7);
            this.Payment.Controls.Add(this.show_bill);
            this.Payment.Location = new System.Drawing.Point(4, 22);
            this.Payment.Name = "Payment";
            this.Payment.Padding = new System.Windows.Forms.Padding(3);
            this.Payment.Size = new System.Drawing.Size(821, 486);
            this.Payment.TabIndex = 1;
            this.Payment.Text = "Payment";
            this.Payment.UseVisualStyleBackColor = true;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label7.Location = new System.Drawing.Point(26, 13);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(92, 25);
            this.label7.TabIndex = 1;
            this.label7.Text = "Receipt";
            // 
            // show_bill
            // 
            this.show_bill.AutoSize = true;
            this.show_bill.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.show_bill.Location = new System.Drawing.Point(25, 47);
            this.show_bill.Name = "show_bill";
            this.show_bill.Size = new System.Drawing.Size(51, 20);
            this.show_bill.TabIndex = 0;
            this.show_bill.Text = "label5";
            // 
            // Home
            // 
            this.Home.AutoScroll = true;
            this.Home.Controls.Add(this.nestca_tea_2);
            this.Home.Controls.Add(this.Nescafe3);
            this.Home.Controls.Add(this.button39);
            this.Home.Controls.Add(this.lemon_tea2);
            this.Home.Controls.Add(this.milk_tea_frappe);
            this.Home.Controls.Add(this.Milk_frappe);
            this.Home.Controls.Add(this.CoCoa_frappe);
            this.Home.Controls.Add(this.Thai_Tea_frappe);
            this.Home.Controls.Add(this.GreenIce_frappe);
            this.Home.Controls.Add(this.Cappuccino_frappe);
            this.Home.Controls.Add(this.Mocha_frappe);
            this.Home.Controls.Add(this.Latte_frappe);
            this.Home.Controls.Add(this.Esspresso_frappe);
            this.Home.Controls.Add(this.honey_lime_soda);
            this.Home.Controls.Add(this.button27);
            this.Home.Controls.Add(this.ls);
            this.Home.Controls.Add(this.nestca_tea);
            this.Home.Controls.Add(this.Nescafe2);
            this.Home.Controls.Add(this.Milk2);
            this.Home.Controls.Add(this.lemon_tea);
            this.Home.Controls.Add(this.milk_tea_ice);
            this.Home.Controls.Add(this.Milk_ice);
            this.Home.Controls.Add(this.CoCoa_ice);
            this.Home.Controls.Add(this.Thai_Tea_ice);
            this.Home.Controls.Add(this.GreenIce_ice);
            this.Home.Controls.Add(this.Cappuccino_ice);
            this.Home.Controls.Add(this.Mocha_ice);
            this.Home.Controls.Add(this.Latte_ice);
            this.Home.Controls.Add(this.Americano_ice);
            this.Home.Controls.Add(this.Esspresso_ice);
            this.Home.Controls.Add(this.nescafe1);
            this.Home.Controls.Add(this.milo1);
            this.Home.Controls.Add(this.Milk_hot);
            this.Home.Controls.Add(this.CoCoa_hot);
            this.Home.Controls.Add(this.Thai_Tea_hot);
            this.Home.Controls.Add(this.GreenIce_hot);
            this.Home.Controls.Add(this.Cappuccino_hot);
            this.Home.Controls.Add(this.Mocha_hot);
            this.Home.Controls.Add(this.Latte_hot);
            this.Home.Controls.Add(this.Americano_hot);
            this.Home.Controls.Add(this.Esspresso_hot);
            this.Home.Controls.Add(this.label3);
            this.Home.Controls.Add(this.label2);
            this.Home.Location = new System.Drawing.Point(4, 22);
            this.Home.Name = "Home";
            this.Home.Padding = new System.Windows.Forms.Padding(3);
            this.Home.Size = new System.Drawing.Size(821, 486);
            this.Home.TabIndex = 0;
            this.Home.Text = "Home";
            this.Home.UseVisualStyleBackColor = true;
            // 
            // nestca_tea_2
            // 
            this.nestca_tea_2.Location = new System.Drawing.Point(746, 264);
            this.nestca_tea_2.Name = "nestca_tea_2";
            this.nestca_tea_2.Size = new System.Drawing.Size(60, 50);
            this.nestca_tea_2.TabIndex = 43;
            this.nestca_tea_2.Text = "Frappe\r\n30 Bath";
            this.nestca_tea_2.UseVisualStyleBackColor = true;
            this.nestca_tea_2.Click += new System.EventHandler(this.nestca_tea_2_Click);
            // 
            // Nescafe3
            // 
            this.Nescafe3.Location = new System.Drawing.Point(746, 217);
            this.Nescafe3.Name = "Nescafe3";
            this.Nescafe3.Size = new System.Drawing.Size(60, 50);
            this.Nescafe3.TabIndex = 42;
            this.Nescafe3.Text = "Frappe\r\n30 Bath";
            this.Nescafe3.UseVisualStyleBackColor = true;
            this.Nescafe3.Click += new System.EventHandler(this.Nescafe3_Click);
            // 
            // button39
            // 
            this.button39.Location = new System.Drawing.Point(746, 166);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(60, 55);
            this.button39.TabIndex = 41;
            this.button39.Text = "Frappe\r\n30 Bath";
            this.button39.UseVisualStyleBackColor = true;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // lemon_tea2
            // 
            this.lemon_tea2.Location = new System.Drawing.Point(746, 119);
            this.lemon_tea2.Name = "lemon_tea2";
            this.lemon_tea2.Size = new System.Drawing.Size(60, 53);
            this.lemon_tea2.TabIndex = 40;
            this.lemon_tea2.Text = "Frappe\r\n30 Bath";
            this.lemon_tea2.UseVisualStyleBackColor = true;
            this.lemon_tea2.Click += new System.EventHandler(this.lemon_tea2_Click);
            // 
            // milk_tea_frappe
            // 
            this.milk_tea_frappe.Location = new System.Drawing.Point(746, 67);
            this.milk_tea_frappe.Name = "milk_tea_frappe";
            this.milk_tea_frappe.Size = new System.Drawing.Size(60, 56);
            this.milk_tea_frappe.TabIndex = 39;
            this.milk_tea_frappe.Text = "Frappe\r\n30 Bath";
            this.milk_tea_frappe.UseVisualStyleBackColor = true;
            this.milk_tea_frappe.Click += new System.EventHandler(this.milk_tea_frappe_Click);
            // 
            // Milk_frappe
            // 
            this.Milk_frappe.Location = new System.Drawing.Point(746, 16);
            this.Milk_frappe.Name = "Milk_frappe";
            this.Milk_frappe.Size = new System.Drawing.Size(60, 54);
            this.Milk_frappe.TabIndex = 38;
            this.Milk_frappe.Text = "Frappe\r\n30 Bath";
            this.Milk_frappe.UseVisualStyleBackColor = true;
            this.Milk_frappe.Click += new System.EventHandler(this.Milk_frappe_Click);
            // 
            // CoCoa_frappe
            // 
            this.CoCoa_frappe.Location = new System.Drawing.Point(331, 358);
            this.CoCoa_frappe.Name = "CoCoa_frappe";
            this.CoCoa_frappe.Size = new System.Drawing.Size(60, 54);
            this.CoCoa_frappe.TabIndex = 37;
            this.CoCoa_frappe.Text = "Frappe\r\n30 Bath";
            this.CoCoa_frappe.UseVisualStyleBackColor = true;
            this.CoCoa_frappe.Click += new System.EventHandler(this.CoCoa_frappe_Click);
            // 
            // Thai_Tea_frappe
            // 
            this.Thai_Tea_frappe.Location = new System.Drawing.Point(331, 311);
            this.Thai_Tea_frappe.Name = "Thai_Tea_frappe";
            this.Thai_Tea_frappe.Size = new System.Drawing.Size(60, 51);
            this.Thai_Tea_frappe.TabIndex = 36;
            this.Thai_Tea_frappe.Text = "Frappe\r\n30 Bath";
            this.Thai_Tea_frappe.UseVisualStyleBackColor = true;
            this.Thai_Tea_frappe.Click += new System.EventHandler(this.Thai_Tea_frappe_Click);
            // 
            // GreenIce_frappe
            // 
            this.GreenIce_frappe.Location = new System.Drawing.Point(331, 264);
            this.GreenIce_frappe.Name = "GreenIce_frappe";
            this.GreenIce_frappe.Size = new System.Drawing.Size(60, 50);
            this.GreenIce_frappe.TabIndex = 35;
            this.GreenIce_frappe.Text = "Frappe\r\n30 Bath";
            this.GreenIce_frappe.UseVisualStyleBackColor = true;
            this.GreenIce_frappe.Click += new System.EventHandler(this.GreenIce_frappe_Click);
            // 
            // Cappuccino_frappe
            // 
            this.Cappuccino_frappe.Location = new System.Drawing.Point(331, 217);
            this.Cappuccino_frappe.Name = "Cappuccino_frappe";
            this.Cappuccino_frappe.Size = new System.Drawing.Size(60, 50);
            this.Cappuccino_frappe.TabIndex = 34;
            this.Cappuccino_frappe.Text = "Frappe\r\n50 Bath";
            this.Cappuccino_frappe.UseVisualStyleBackColor = true;
            this.Cappuccino_frappe.Click += new System.EventHandler(this.Cappuccino_frappe_Click);
            // 
            // Mocha_frappe
            // 
            this.Mocha_frappe.Location = new System.Drawing.Point(331, 168);
            this.Mocha_frappe.Name = "Mocha_frappe";
            this.Mocha_frappe.Size = new System.Drawing.Size(60, 53);
            this.Mocha_frappe.TabIndex = 33;
            this.Mocha_frappe.Text = "Frappe\r\n50 Bath";
            this.Mocha_frappe.UseVisualStyleBackColor = true;
            this.Mocha_frappe.Click += new System.EventHandler(this.Mocha_frappe_Click);
            // 
            // Latte_frappe
            // 
            this.Latte_frappe.Location = new System.Drawing.Point(331, 119);
            this.Latte_frappe.Name = "Latte_frappe";
            this.Latte_frappe.Size = new System.Drawing.Size(60, 53);
            this.Latte_frappe.TabIndex = 32;
            this.Latte_frappe.Text = "Frappe\r\n50 Bath";
            this.Latte_frappe.UseVisualStyleBackColor = true;
            this.Latte_frappe.Click += new System.EventHandler(this.Latte_frappe_Click);
            // 
            // Esspresso_frappe
            // 
            this.Esspresso_frappe.Location = new System.Drawing.Point(331, 16);
            this.Esspresso_frappe.Name = "Esspresso_frappe";
            this.Esspresso_frappe.Size = new System.Drawing.Size(60, 54);
            this.Esspresso_frappe.TabIndex = 31;
            this.Esspresso_frappe.Text = "Frappe\r\n50 Bath";
            this.Esspresso_frappe.UseVisualStyleBackColor = true;
            this.Esspresso_frappe.Click += new System.EventHandler(this.Esspresso_frappe_Click);
            // 
            // honey_lime_soda
            // 
            this.honey_lime_soda.Location = new System.Drawing.Point(662, 409);
            this.honey_lime_soda.Name = "honey_lime_soda";
            this.honey_lime_soda.Size = new System.Drawing.Size(60, 53);
            this.honey_lime_soda.TabIndex = 30;
            this.honey_lime_soda.Text = "Ice\r\n25 Bath";
            this.honey_lime_soda.UseVisualStyleBackColor = true;
            this.honey_lime_soda.Click += new System.EventHandler(this.honey_lime_soda_Click);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(662, 358);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(60, 54);
            this.button27.TabIndex = 29;
            this.button27.Text = "Ice\r\n25 Bath";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // ls
            // 
            this.ls.Location = new System.Drawing.Point(662, 311);
            this.ls.Name = "ls";
            this.ls.Size = new System.Drawing.Size(60, 51);
            this.ls.TabIndex = 28;
            this.ls.Text = "Ice\r\n25 Bath";
            this.ls.UseVisualStyleBackColor = true;
            this.ls.Click += new System.EventHandler(this.ls_Click);
            // 
            // nestca_tea
            // 
            this.nestca_tea.Location = new System.Drawing.Point(662, 264);
            this.nestca_tea.Name = "nestca_tea";
            this.nestca_tea.Size = new System.Drawing.Size(60, 50);
            this.nestca_tea.TabIndex = 26;
            this.nestca_tea.Text = "Ice\r\n25 Bath";
            this.nestca_tea.UseVisualStyleBackColor = true;
            this.nestca_tea.Click += new System.EventHandler(this.nestca_tea_Click);
            // 
            // Nescafe2
            // 
            this.Nescafe2.Location = new System.Drawing.Point(662, 217);
            this.Nescafe2.Name = "Nescafe2";
            this.Nescafe2.Size = new System.Drawing.Size(60, 50);
            this.Nescafe2.TabIndex = 27;
            this.Nescafe2.Text = "Ice\r\n25 Bath";
            this.Nescafe2.UseVisualStyleBackColor = true;
            this.Nescafe2.Click += new System.EventHandler(this.Nescafe2_Click);
            // 
            // Milk2
            // 
            this.Milk2.Location = new System.Drawing.Point(662, 166);
            this.Milk2.Name = "Milk2";
            this.Milk2.Size = new System.Drawing.Size(60, 55);
            this.Milk2.TabIndex = 26;
            this.Milk2.Text = "Ice\r\n25 Bath";
            this.Milk2.UseVisualStyleBackColor = true;
            this.Milk2.Click += new System.EventHandler(this.Milk2_Click);
            // 
            // lemon_tea
            // 
            this.lemon_tea.Location = new System.Drawing.Point(662, 119);
            this.lemon_tea.Name = "lemon_tea";
            this.lemon_tea.Size = new System.Drawing.Size(60, 53);
            this.lemon_tea.TabIndex = 25;
            this.lemon_tea.Text = "Ice\r\n25 Bath";
            this.lemon_tea.UseVisualStyleBackColor = true;
            this.lemon_tea.Click += new System.EventHandler(this.lemon_tea_Click);
            // 
            // milk_tea_ice
            // 
            this.milk_tea_ice.Location = new System.Drawing.Point(662, 67);
            this.milk_tea_ice.Name = "milk_tea_ice";
            this.milk_tea_ice.Size = new System.Drawing.Size(60, 56);
            this.milk_tea_ice.TabIndex = 24;
            this.milk_tea_ice.Text = "Ice\r\n25 Bath";
            this.milk_tea_ice.UseVisualStyleBackColor = true;
            this.milk_tea_ice.Click += new System.EventHandler(this.milk_tea_ice_Click);
            // 
            // Milk_ice
            // 
            this.Milk_ice.Location = new System.Drawing.Point(662, 16);
            this.Milk_ice.Name = "Milk_ice";
            this.Milk_ice.Size = new System.Drawing.Size(60, 54);
            this.Milk_ice.TabIndex = 23;
            this.Milk_ice.Text = "Ice\r\n25 Bath";
            this.Milk_ice.UseVisualStyleBackColor = true;
            this.Milk_ice.Click += new System.EventHandler(this.Milk_ice_Click);
            // 
            // CoCoa_ice
            // 
            this.CoCoa_ice.Location = new System.Drawing.Point(244, 358);
            this.CoCoa_ice.Name = "CoCoa_ice";
            this.CoCoa_ice.Size = new System.Drawing.Size(60, 54);
            this.CoCoa_ice.TabIndex = 22;
            this.CoCoa_ice.Text = "Ice\r\n25 Bath";
            this.CoCoa_ice.UseVisualStyleBackColor = true;
            this.CoCoa_ice.Click += new System.EventHandler(this.CoCoa_ice_Click);
            // 
            // Thai_Tea_ice
            // 
            this.Thai_Tea_ice.Location = new System.Drawing.Point(244, 311);
            this.Thai_Tea_ice.Name = "Thai_Tea_ice";
            this.Thai_Tea_ice.Size = new System.Drawing.Size(60, 51);
            this.Thai_Tea_ice.TabIndex = 21;
            this.Thai_Tea_ice.Text = "Ice\r\n25 Bath";
            this.Thai_Tea_ice.UseVisualStyleBackColor = true;
            this.Thai_Tea_ice.Click += new System.EventHandler(this.Thai_Tea_ice_Click);
            // 
            // GreenIce_ice
            // 
            this.GreenIce_ice.Location = new System.Drawing.Point(244, 264);
            this.GreenIce_ice.Name = "GreenIce_ice";
            this.GreenIce_ice.Size = new System.Drawing.Size(60, 50);
            this.GreenIce_ice.TabIndex = 20;
            this.GreenIce_ice.Text = "Ice\r\n25 Bath";
            this.GreenIce_ice.UseVisualStyleBackColor = true;
            this.GreenIce_ice.Click += new System.EventHandler(this.GreenIce_ice_Click);
            // 
            // Cappuccino_ice
            // 
            this.Cappuccino_ice.Location = new System.Drawing.Point(244, 217);
            this.Cappuccino_ice.Name = "Cappuccino_ice";
            this.Cappuccino_ice.Size = new System.Drawing.Size(60, 50);
            this.Cappuccino_ice.TabIndex = 19;
            this.Cappuccino_ice.Text = "Ice\r\n45 Bath";
            this.Cappuccino_ice.UseVisualStyleBackColor = true;
            this.Cappuccino_ice.Click += new System.EventHandler(this.Cappuccino_ice_Click);
            // 
            // Mocha_ice
            // 
            this.Mocha_ice.Location = new System.Drawing.Point(244, 168);
            this.Mocha_ice.Name = "Mocha_ice";
            this.Mocha_ice.Size = new System.Drawing.Size(60, 53);
            this.Mocha_ice.TabIndex = 18;
            this.Mocha_ice.Text = "Ice\r\n45 Bath";
            this.Mocha_ice.UseVisualStyleBackColor = true;
            this.Mocha_ice.Click += new System.EventHandler(this.Mocha_ice_Click);
            // 
            // Latte_ice
            // 
            this.Latte_ice.Location = new System.Drawing.Point(244, 119);
            this.Latte_ice.Name = "Latte_ice";
            this.Latte_ice.Size = new System.Drawing.Size(60, 53);
            this.Latte_ice.TabIndex = 17;
            this.Latte_ice.Text = "Ice\r\n45 Bath";
            this.Latte_ice.UseVisualStyleBackColor = true;
            this.Latte_ice.Click += new System.EventHandler(this.Latte_ice_Click);
            // 
            // Americano_ice
            // 
            this.Americano_ice.Location = new System.Drawing.Point(244, 67);
            this.Americano_ice.Name = "Americano_ice";
            this.Americano_ice.Size = new System.Drawing.Size(60, 56);
            this.Americano_ice.TabIndex = 16;
            this.Americano_ice.Text = "Ice\r\n45 Bath";
            this.Americano_ice.UseVisualStyleBackColor = true;
            this.Americano_ice.Click += new System.EventHandler(this.Americano_ice_Click);
            // 
            // Esspresso_ice
            // 
            this.Esspresso_ice.Location = new System.Drawing.Point(244, 16);
            this.Esspresso_ice.Name = "Esspresso_ice";
            this.Esspresso_ice.Size = new System.Drawing.Size(60, 54);
            this.Esspresso_ice.TabIndex = 15;
            this.Esspresso_ice.Text = "Ice\r\n45 Bath";
            this.Esspresso_ice.UseVisualStyleBackColor = true;
            this.Esspresso_ice.Click += new System.EventHandler(this.Esspresso_ice_Click);
            // 
            // nescafe1
            // 
            this.nescafe1.Location = new System.Drawing.Point(576, 215);
            this.nescafe1.Name = "nescafe1";
            this.nescafe1.Size = new System.Drawing.Size(60, 52);
            this.nescafe1.TabIndex = 14;
            this.nescafe1.Text = "Hot\r\n20 Bath";
            this.nescafe1.UseVisualStyleBackColor = true;
            this.nescafe1.Click += new System.EventHandler(this.nescafe1_Click);
            // 
            // milo1
            // 
            this.milo1.Location = new System.Drawing.Point(576, 168);
            this.milo1.Name = "milo1";
            this.milo1.Size = new System.Drawing.Size(60, 53);
            this.milo1.TabIndex = 13;
            this.milo1.Text = "Hot\r\n20 Bath";
            this.milo1.UseVisualStyleBackColor = true;
            this.milo1.Click += new System.EventHandler(this.milo1_Click);
            // 
            // Milk_hot
            // 
            this.Milk_hot.Location = new System.Drawing.Point(576, 16);
            this.Milk_hot.Name = "Milk_hot";
            this.Milk_hot.Size = new System.Drawing.Size(60, 54);
            this.Milk_hot.TabIndex = 12;
            this.Milk_hot.Text = "Hot\r\n20 Bath";
            this.Milk_hot.UseVisualStyleBackColor = true;
            this.Milk_hot.Click += new System.EventHandler(this.Milk_hot_Click);
            // 
            // CoCoa_hot
            // 
            this.CoCoa_hot.Location = new System.Drawing.Point(150, 358);
            this.CoCoa_hot.Name = "CoCoa_hot";
            this.CoCoa_hot.Size = new System.Drawing.Size(60, 54);
            this.CoCoa_hot.TabIndex = 11;
            this.CoCoa_hot.Text = "Hot\r\n20 Bath";
            this.CoCoa_hot.UseVisualStyleBackColor = true;
            this.CoCoa_hot.Click += new System.EventHandler(this.CoCoa_hot_Click);
            // 
            // Thai_Tea_hot
            // 
            this.Thai_Tea_hot.Location = new System.Drawing.Point(150, 311);
            this.Thai_Tea_hot.Name = "Thai_Tea_hot";
            this.Thai_Tea_hot.Size = new System.Drawing.Size(60, 51);
            this.Thai_Tea_hot.TabIndex = 10;
            this.Thai_Tea_hot.Text = "Hot\r\n20 Bath";
            this.Thai_Tea_hot.UseVisualStyleBackColor = true;
            this.Thai_Tea_hot.Click += new System.EventHandler(this.Thai_Tea_hot_Click);
            // 
            // GreenIce_hot
            // 
            this.GreenIce_hot.Location = new System.Drawing.Point(150, 264);
            this.GreenIce_hot.Name = "GreenIce_hot";
            this.GreenIce_hot.Size = new System.Drawing.Size(60, 50);
            this.GreenIce_hot.TabIndex = 9;
            this.GreenIce_hot.Text = "Hot\r\n20 Bath";
            this.GreenIce_hot.UseVisualStyleBackColor = true;
            this.GreenIce_hot.Click += new System.EventHandler(this.GreenIce_hot_Click);
            // 
            // Cappuccino_hot
            // 
            this.Cappuccino_hot.Location = new System.Drawing.Point(150, 217);
            this.Cappuccino_hot.Name = "Cappuccino_hot";
            this.Cappuccino_hot.Size = new System.Drawing.Size(60, 50);
            this.Cappuccino_hot.TabIndex = 7;
            this.Cappuccino_hot.Text = "Hot\r\n35 Bath";
            this.Cappuccino_hot.UseVisualStyleBackColor = true;
            this.Cappuccino_hot.Click += new System.EventHandler(this.Cappuccino_hot_Click);
            // 
            // Mocha_hot
            // 
            this.Mocha_hot.Location = new System.Drawing.Point(150, 168);
            this.Mocha_hot.Name = "Mocha_hot";
            this.Mocha_hot.Size = new System.Drawing.Size(60, 53);
            this.Mocha_hot.TabIndex = 6;
            this.Mocha_hot.Text = "Hot\r\n35 Bath";
            this.Mocha_hot.UseVisualStyleBackColor = true;
            this.Mocha_hot.Click += new System.EventHandler(this.Mocha_hot_Click);
            // 
            // Latte_hot
            // 
            this.Latte_hot.Location = new System.Drawing.Point(150, 119);
            this.Latte_hot.Name = "Latte_hot";
            this.Latte_hot.Size = new System.Drawing.Size(60, 53);
            this.Latte_hot.TabIndex = 5;
            this.Latte_hot.Text = "Hot\r\n35 Bath";
            this.Latte_hot.UseVisualStyleBackColor = true;
            this.Latte_hot.Click += new System.EventHandler(this.Latte_hot_Click);
            // 
            // Americano_hot
            // 
            this.Americano_hot.Location = new System.Drawing.Point(150, 67);
            this.Americano_hot.Name = "Americano_hot";
            this.Americano_hot.Size = new System.Drawing.Size(60, 56);
            this.Americano_hot.TabIndex = 4;
            this.Americano_hot.Text = "Hot\r\n35 Bath";
            this.Americano_hot.UseVisualStyleBackColor = true;
            this.Americano_hot.Click += new System.EventHandler(this.Americano_hot_Click);
            // 
            // Esspresso_hot
            // 
            this.Esspresso_hot.Location = new System.Drawing.Point(150, 16);
            this.Esspresso_hot.Name = "Esspresso_hot";
            this.Esspresso_hot.Size = new System.Drawing.Size(60, 54);
            this.Esspresso_hot.TabIndex = 3;
            this.Esspresso_hot.Text = "Hot\r\n35 Bath";
            this.Esspresso_hot.UseVisualStyleBackColor = true;
            this.Esspresso_hot.Click += new System.EventHandler(this.Esspresso_hot_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label3.Location = new System.Drawing.Point(400, 16);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(175, 425);
            this.label3.TabIndex = 2;
            this.label3.Text = "Milk\r\n\r\nMilk Tea\r\n\r\nLemon Tea\r\n\r\nMilo\r\n\r\nNescafe\r\n\r\nNestcaTea\r\n\r\nItalian Soda\r\n\r\n" +
    "Red lime Soda\r\n\r\nHoney lime Soda";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label2.Location = new System.Drawing.Point(6, 16);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(126, 375);
            this.label2.TabIndex = 1;
            this.label2.Text = "Esspresso\r\n\r\nAmericano\r\n\r\nLatte\r\n\r\nMocha\r\n\r\nCappuccino\r\n\r\nGreen Tea\r\n\r\nThai Tea\r\n" +
    "\r\nCoCoa";
            // 
            // ok_pay
            // 
            this.ok_pay.Location = new System.Drawing.Point(1139, 548);
            this.ok_pay.Name = "ok_pay";
            this.ok_pay.Size = new System.Drawing.Size(104, 44);
            this.ok_pay.TabIndex = 0;
            this.ok_pay.Text = "Payment";
            this.ok_pay.UseVisualStyleBackColor = true;
            this.ok_pay.Click += new System.EventHandler(this.ok_pay_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Home);
            this.tabControl1.Controls.Add(this.Payment);
            this.tabControl1.Controls.Add(this.About);
            this.tabControl1.Location = new System.Drawing.Point(12, 91);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(829, 512);
            this.tabControl1.TabIndex = 1;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label4.Location = new System.Drawing.Point(882, 451);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(108, 24);
            this.label4.TabIndex = 3;
            this.label4.Text = "Total price :";
            // 
            // p_txt
            // 
            this.p_txt.AutoSize = true;
            this.p_txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.p_txt.Location = new System.Drawing.Point(1020, 451);
            this.p_txt.Name = "p_txt";
            this.p_txt.Size = new System.Drawing.Size(0, 25);
            this.p_txt.TabIndex = 4;
            // 
            // clear
            // 
            this.clear.Location = new System.Drawing.Point(1154, 62);
            this.clear.Name = "clear";
            this.clear.Size = new System.Drawing.Size(89, 45);
            this.clear.TabIndex = 6;
            this.clear.Text = "Clear";
            this.clear.UseVisualStyleBackColor = true;
            this.clear.Click += new System.EventHandler(this.clear_Click_1);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label6.Location = new System.Drawing.Point(848, 484);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(142, 24);
            this.label6.TabIndex = 7;
            this.label6.Text = "Receive Money";
            // 
            // receive_money
            // 
            this.receive_money.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.receive_money.Location = new System.Drawing.Point(996, 488);
            this.receive_money.Name = "receive_money";
            this.receive_money.Size = new System.Drawing.Size(100, 29);
            this.receive_money.TabIndex = 8;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label8.Location = new System.Drawing.Point(1119, 484);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 24);
            this.label8.TabIndex = 9;
            this.label8.Text = "baht";
            // 
            // Give_the_change
            // 
            this.Give_the_change.AutoSize = true;
            this.Give_the_change.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.Give_the_change.Location = new System.Drawing.Point(848, 527);
            this.Give_the_change.Name = "Give_the_change";
            this.Give_the_change.Size = new System.Drawing.Size(158, 24);
            this.Give_the_change.TabIndex = 10;
            this.Give_the_change.Text = "Give the change :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(222)));
            this.label9.Location = new System.Drawing.Point(1224, 9);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(19, 18);
            this.label9.TabIndex = 11;
            this.label9.Text = "X";
            this.label9.Click += new System.EventHandler(this.label9_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1255, 604);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.Give_the_change);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.receive_money);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.clear);
            this.Controls.Add(this.p_txt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.listView1);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.ok_pay);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Text = "TonTan Coffee";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.About.ResumeLayout(false);
            this.About.PerformLayout();
            this.Payment.ResumeLayout(false);
            this.Payment.PerformLayout();
            this.Home.ResumeLayout(false);
            this.Home.PerformLayout();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.ColumnHeader columnHeader1;
        private System.Windows.Forms.ColumnHeader columnHeader2;
        private System.Windows.Forms.TabPage About;
        private System.Windows.Forms.TabPage Payment;
        private System.Windows.Forms.TabPage Home;
        private System.Windows.Forms.Button nestca_tea_2;
        private System.Windows.Forms.Button Nescafe3;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button lemon_tea2;
        private System.Windows.Forms.Button milk_tea_frappe;
        private System.Windows.Forms.Button Milk_frappe;
        private System.Windows.Forms.Button CoCoa_frappe;
        private System.Windows.Forms.Button Thai_Tea_frappe;
        private System.Windows.Forms.Button GreenIce_frappe;
        private System.Windows.Forms.Button Cappuccino_frappe;
        private System.Windows.Forms.Button Mocha_frappe;
        private System.Windows.Forms.Button Latte_frappe;
        private System.Windows.Forms.Button Esspresso_frappe;
        private System.Windows.Forms.Button honey_lime_soda;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button ls;
        private System.Windows.Forms.Button nestca_tea;
        private System.Windows.Forms.Button Nescafe2;
        private System.Windows.Forms.Button Milk2;
        private System.Windows.Forms.Button lemon_tea;
        private System.Windows.Forms.Button milk_tea_ice;
        private System.Windows.Forms.Button Milk_ice;
        private System.Windows.Forms.Button CoCoa_ice;
        private System.Windows.Forms.Button Thai_Tea_ice;
        private System.Windows.Forms.Button GreenIce_ice;
        private System.Windows.Forms.Button Cappuccino_ice;
        private System.Windows.Forms.Button Mocha_ice;
        private System.Windows.Forms.Button Latte_ice;
        private System.Windows.Forms.Button Americano_ice;
        private System.Windows.Forms.Button Esspresso_ice;
        private System.Windows.Forms.Button nescafe1;
        private System.Windows.Forms.Button milo1;
        private System.Windows.Forms.Button Milk_hot;
        private System.Windows.Forms.Button CoCoa_hot;
        private System.Windows.Forms.Button Thai_Tea_hot;
        private System.Windows.Forms.Button GreenIce_hot;
        private System.Windows.Forms.Button Cappuccino_hot;
        private System.Windows.Forms.Button Mocha_hot;
        private System.Windows.Forms.Button Latte_hot;
        private System.Windows.Forms.Button Americano_hot;
        private System.Windows.Forms.Button Esspresso_hot;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button ok_pay;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label p_txt;
        private System.Windows.Forms.Label show_bill;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel linkLabel3;
        private System.Windows.Forms.LinkLabel linkLabel2;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.Button clear;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox receive_money;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label Give_the_change;
        private System.Windows.Forms.Label label9;
    }
}

